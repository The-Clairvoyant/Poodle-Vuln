[Google recently announced][poodle] that there is an exploit in SSLv3, this vulnerability is
know as POODLE. There is no other option than to disable SSLv3 in order to combat this major
flaw. There have already been [guides on how to disable this in different servers][guides].
But nothing excised for Node.js yet, until now. In order to resolve this for Node.js we need
to use various of undocumented options and modules.

In the `index.js` file below you can see an example of how you can protect your HTTPS server
against the POODLE attack. It uses the `secureOptions` option to pass in constants in to the
SSL context which is created by node.

Start the server locally by running:

```js
sudo node index.js
```

And see if SSLv3 is correctly disabled by connecting with an
openssl client:

```
openssl s_client -connect 127.0.0.1:443 -ssl3
```

It should respond with a handshake failure:

```
CONNECTED(00000003)
47309:error:1409E0E5:SSL routines:SSL3_WRITE_BYTES:ssl handshake failure:/SourceCache/OpenSSL098/OpenSSL098-52/src/ssl/s3_pkt.c:546:
```

If we connect normally, it will just work:

```
openssl s_client -connect 127.0.0.1:443
```

[poodle]: http://googleonlinesecurity.blogspot.nl/2014/10/this-poodle-bites-exploiting-ssl-30.html
[guides]: http://askubuntu.com/questions/537196/how-do-i-patch-workaround-sslv3-poodle-vulnerability-cve-2014-3566